# Automatic Computer System Builder README

## Build instructions

build war files: gradle war

start app on port 8080: gradle appstart

to stop: gradle appstop

## Status

### Frontend   

**Coming Soon** 
  
### Backend

**Coming Soon** 
  
## How To Use
  
**Coming Soon** 

## Configuration

**Coming Soon** 

## Repo Organization
Refer to Design Document

## Application Behavior Flow

**Coming Soon**
